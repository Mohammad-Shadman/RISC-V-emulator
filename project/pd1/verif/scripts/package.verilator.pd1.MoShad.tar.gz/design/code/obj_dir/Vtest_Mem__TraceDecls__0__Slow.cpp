// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing declarations
#include "verilated_vcd_c.h"


void Vtest_Mem___024root__traceDeclTypesSub0(VerilatedVcd* tracep) {
}

void Vtest_Mem___024root__trace_decl_types(VerilatedVcd* tracep) {
    Vtest_Mem___024root__traceDeclTypesSub0(tracep);
}
